<?php

namespace App\Http\Requests\Adminsite\Regency;

use Illuminate\Foundation\Http\FormRequest;

class CreateRules extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'province_id' => 'required|exists:province,id',
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'Name is required',
            'name.string' => 'Name must be a string',
            'name.max' => 'Name must not exceed 255 characters',
            'province_id.required' => 'Province is required',
            'province_id.exists' => 'Province does not exist',
        ];
    }
}
