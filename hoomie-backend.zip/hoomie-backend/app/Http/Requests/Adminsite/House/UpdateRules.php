<?php

namespace App\Http\Requests\Adminsite\House;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRules extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'category_id' => 'required|exists:categories,id',
            'province_id' => 'required|exists:provinces,id',
            'city_id' => 'required|exists:city,id',
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'price' => 'required|numeric',
            'price_type' => 'required|string|max:255',
            'description' => 'required|string',
            'electrical_power' => 'required|max:255',
            'car_ports' => 'required|max:255',
            'number_of_floors' => 'required|max:255',
            'building_orientation' => 'required|max:255',
            'year_built' => 'required|max:255',
            'number_of_bedrooms' => 'required|max:255',
        ];
    }

    public function messages()
    {
        return [
            'category_id.required' => 'Categories is required.',
            'category_id.exists' => 'Categories does not exist.',
            'province_id.required' => 'Province is required.',
            'province_id.exists' => 'Province does not exist.',
            'city_id.required' => 'City is required.',
            'city_id.exists' => 'City does not exist.',
            'name.required' => 'Name is required.',
            'name.string' => 'Name must be a string.',
            'name.max' => 'Name must not exceed 255 characters.',
            'address.required' => 'Address is required.',
            'address.string' => 'Address must be a string.',
            'address.max' => 'Address must not exceed 255 characters.',
            'price.required' => 'Price is required.',
            'price.numeric' => 'Price must be a number.',
            'price_type.required' => 'Price Type is required.',
            'price_type.string' => 'Price Type must be a string.',
            'price_type.max' => 'Price Type must not exceed 255 characters.',
            'description.required' => 'Description is required.',   
            'description.string' => 'Description must be a string.',
            'electrical_power.required' => 'Electrical Power is required.',
            'electrical_power.string' => 'Electrical Power must be a string.',
            'electrical_power.max' => 'Electrical Power must not exceed 255 characters.',
            'car_ports.required' => 'Car Ports is required.',
            'car_ports.string' => 'Car Ports must be a string.',
            'car_ports.max' => 'Car Ports must not exceed 255 characters.',
            'number_of_floors.required' => 'Number of Floors is required.',
            'number_of_floors.string' => 'Number of Floors must be a string.',
            'number_of_floors.max' => 'Number of Floors must not exceed 255 characters.',
            'building_orientation.required' => 'Building Orientation is required.',
            'building_orientation.string' => 'Building Orientation must be a string.',
            'building_orientation.max' => 'Building Orientation must not exceed 255 characters.',
            'year_built.required' => 'Year Built is required.',
            'year_built.string' => 'Year Built must be a string.',
            'year_built.max' => 'Year Built must not exceed 255 characters.',
            'number_of_bedrooms.required' => 'Number of Bedrooms is required.',
            'number_of_bedrooms.string' => 'Number of Bedrooms must be a string.',
            'number_of_bedrooms.max' => 'Number of Bedrooms must not exceed 255 characters.',
        ];
    }
}
