<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HouseComment extends Model
{
    protected $table = 'house_comments';

    protected $fillable = [
        'house_id',
        'user_id',
        'comment',
    ];

    protected $casts = [
        'house_id' => 'integer',
        'user_id' => 'integer',
        'comment' => 'string',
        'created_at' => 'datetime:Y-m-d H:i:s',
        'updated_at' => 'datetime:Y-m-d H:i:s',
    ];
}
