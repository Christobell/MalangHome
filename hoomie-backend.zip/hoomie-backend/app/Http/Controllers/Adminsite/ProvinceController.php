<?php

namespace App\Http\Controllers\Adminsite;

use Exception;
use App\Models\Province;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Adminsite\Province\CreateRules;
use App\Http\Requests\Adminsite\Province\UpdateRules;

class ProvinceController extends Controller
{
    public function getAll(Request $request)
    {
        try {
            $data = Province::orderBy('id', 'desc')->paginate(10, ['*'], 'page', $request->query('page'));
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data->items(),
                'pagination' => [
                    'current_page' => $data->currentPage(),
                    'last_page' => $data->lastPage(),
                    'per_page' => $data->perPage(),
                    'total' => $data->total(),
                ]
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
    
    public function getOption(){
        try{
            $data = Province::all();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        }catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function getById($id)
    {
        try {
            $data = Province::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function create(CreateRules $request)
    {
        try {
            $request->validated();
            $data = Province::create($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function update(UpdateRules $request, $id)
    {
        try {
            $request->validated();
            $data = Province::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found'
                ], 404);
            }
            $data->update($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function delete($id)
    {
        try {
            $data = Province::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $data->delete();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
}
