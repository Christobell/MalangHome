<?php

namespace App\Http\Controllers\Adminsite;

use App\Http\Controllers\Controller;
use App\Http\Requests\Adminsite\House\CreateRules;
use App\Http\Requests\Adminsite\House\UpdateRules;
use App\Models\House;
use App\Models\HouseDetails;
use App\Models\HouseImages;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Laravel\Sanctum\PersonalAccessToken;
use Laravel\Sanctum\Sanctum;

class HouseController extends Controller
{
    public function __construct(Request $request)
    {
        $token = $request->bearerToken();
        $tokenModel = PersonalAccessToken::findToken($token);
        $this->user = $tokenModel->tokenable;
    }

    public function getAll(Request $request)
    {
        try {
            if($this->user->hasRole('user')) {
                $data = House::with(['user', 'category', 'city', 'province', 'detail'])->where('user_id', $this->user->id)->paginate(10, ['*'], 'page', $request->query('page'));
            }else{
                $data = House::with(['user', 'category', 'city', 'province', 'detail'])->paginate(10, ['*'], 'page', $request->query('page'));
            }
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data->items(),
                'pagination' => [
                    'current_page' => $data->currentPage(),
                    'last_page' => $data->lastPage(),
                    'per_page' => $data->perPage(),
                    'total' => $data->total(),
                ],
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function getById($id)
    {
        try {
            $data = House::with(['user', 'category', 'city', 'province', 'detail'])->find($id);
            if (! $data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function create(CreateRules $request)
    {
        try {
            $request->validated();
            $house = House::create([
                'user_id' => $this->user->id,
                'category_id' => $request->category_id,
                'city_id' => $request->city_id,
                'province_id' => $request->province_id,
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'price_type' => $request->price_type,
                'address' => $request->address,
            ]);
            $houseDetail = HouseDetails::create([
                'house_id' => $house->id,
                'electrical_power' => $request->electrical_power,
                'car_ports' => $request->car_ports,
                'number_of_floors' => $request->number_of_floors,
                'building_orientation' => $request->building_orientation,
                'year_built' => $request->year_built,
                'number_of_bedrooms' => $request->number_of_bedrooms,
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $house,
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function update(UpdateRules $request, $id)
    {
        try {
            $request->validated();
            $data = House::find($id);
            if (! $data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $data->update([
                'user_id' => $this->user->id,
                'category_id' => $request->category_id,
                'city_id' => $request->city_id,
                'province_id' => $request->province_id,
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'price_type' => $request->price_type,
                'address' => $request->address,
            ]);
            $data->detail->update([
                'electrical_power' => $request->electrical_power,
                'car_ports' => $request->car_ports,
                'number_of_floors' => $request->number_of_floors,
                'building_orientation' => $request->building_orientation,
                'year_built' => $request->year_built,
                'number_of_bedrooms' => $request->number_of_bedrooms,
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function delete($id)
    {
        try {
            $data = House::find($id);
            if (! $data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $data->delete();

            return response()->json([
                'status' => true,
                'message' => 'Success',
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function getHouseImage($id)
    {
        try {
            $data = HouseImages::where('house_id', $id)->get();
            $map = $data->map(function ($item) {
                $image = Storage::disk('s3')->url($item->image);
                return [
                    'id' => $item->id,
                    'image' => $image,
                ];
            });

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $map,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function addHouseImage(Request $request, $id)
    {
        try {
            $data = House::find($id);
            if (! $data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $filePath = 'house/';
            $fileName = Str::random().'.'.'png';
            $image = explode(',', $request->image);
            $image = $image[1];
            $image = base64_decode($image, true);
            $storage = Storage::disk('s3')->put($filePath.$fileName, $image, 'public');
            HouseImages::create([
                'house_id' => $data->id,
                'image' => $filePath.$fileName,
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => null,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function deleteHouseImage($id)
    {
        try {
            $data = HouseImages::find($id);
            if (! $data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            Storage::disk('s3')->delete($data->image);
            $data->delete();
            return response()->json([
                'status' => true,
                'message' => 'Success',
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }
}
