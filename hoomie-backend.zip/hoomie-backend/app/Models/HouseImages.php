<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class HouseImages extends Model
{
    protected $table = 'house_images';

    protected $fillable = [
        'house_id',
        'image',
    ];

    protected $casts = [
        'house_id' => 'integer',
        'image' => 'string',
    ];

    protected function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->image
                ? Storage::disk('s3')->url($this->image)
                : null,
        );
    }

    protected $appends = ['image_url'];
}
