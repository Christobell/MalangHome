<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('house_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('house_id')->references('id')->on('houses')->onDelete('cascade');
            $table->string('electrical_power');
            $table->string('car_ports');
            $table->string('number_of_floors');
            $table->string('building_orientation');
            $table->string('year_built');
            $table->string('number_of_bedrooms');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('house_details');
    }
};
