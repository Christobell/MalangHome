<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::create([
            'fullname' => 'Admin',
            'phone' => '08154654465',
            'email' => 'admin@example.com',
            'password' => Hash::make('123456'),
        ]);
        $user->assignRole('admin');
    }
}
