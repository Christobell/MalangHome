<?php

namespace App\Http\Controllers\Adminsite;

use Exception;
use App\Models\City;
use App\Models\House;
use App\Models\Province;
use App\Models\Categories;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OverviewController extends Controller
{
    public function getOverview(){
        try {
            $totalCategories = Categories::count();
            $totalCity = City::count();
            $totalHouse = House::count();
            $totalProvince = Province::count();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => [
                    'totalCategories' => $totalCategories,
                    'totalCity' => $totalCity,
                    'totalHouse' => $totalHouse,
                    'totalProvince' => $totalProvince
                ]
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
}
