<?php

namespace App\Http\Controllers\Adminsite;

use Exception;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Adminsite\Categories\CreateRules;
use App\Http\Requests\Adminsite\Categories\UpdateRules;
use App\Models\Categories;

class CategoriesController extends Controller
{
    public function getAll(Request $request)
    {
        try {
            $data = Categories::paginate(10, ['*'], 'page', $request->query('page'));
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data->items(),
                'pagination' => [
                    'current_page' => $data->currentPage(),
                    'last_page' => $data->lastPage(),
                    'per_page' => $data->perPage(),
                    'total' => $data->total(),
                ]
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function getOption(){
        try{
            $data = Categories::all();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        }catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function getById($id)
    {
        try {
            $data = Categories::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function create(CreateRules $request)
    {
        try {
            $request->validated();
            $data = Categories::create($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function update(UpdateRules $request, $id)
    {
        try {
            $request->validated();
            $data = Categories::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $data->update($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function delete($id)
    {
        try {
            $data = Categories::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $data->delete();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
}
