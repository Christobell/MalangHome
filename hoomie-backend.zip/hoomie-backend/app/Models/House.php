<?php

namespace App\Models;

use App\Models\HouseDetails;
use Illuminate\Database\Eloquent\Model;

class House extends Model
{
    protected $table = 'houses';
    protected $fillable = [
        'user_id',
        'category_id',
        'city_id',
        'province_id',
        'name',
        'description',
        'price',
        'price_type',
        'address',
    ];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
        'updated_at' => 'datetime:Y-m-d H:i:s'
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function category(){
        return $this->belongsTo(Categories::class, 'category_id', 'id');
    }

    public function city(){
        return $this->belongsTo(City::class, 'city_id', 'id');
    }

    public function province(){
        return $this->belongsTo(Province::class, 'province_id', 'id');
    }

    public function detail()
    {
        return $this->belongsTo(HouseDetails::class, 'id', 'house_id');
    }

    public function singleImage()
    {
        return $this->hasOne(HouseImages::class, 'house_id', 'id');
    }

    public function images()
    {
        return $this->hasMany(HouseImages::class, 'house_id', 'id');
    }
}
