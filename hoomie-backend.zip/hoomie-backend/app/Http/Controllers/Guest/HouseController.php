<?php

namespace App\Http\Controllers\Guest;

use App\Http\Controllers\Controller;
use App\Models\Categories;
use App\Models\House;
use App\Models\Province;
use Exception;
use Illuminate\Http\Request;

class HouseController extends Controller
{
    public function getHouse(Request $request)
    {
        $total = $request->query('total');
        $category = $request->query('category_id');
        $province = $request->query('province_id');
        $search = $request->query('search');
        $query = House::with(['user', 'category', 'city', 'province', 'detail', 'singleImage']);

        if ($total !== null && is_numeric($total) && (int) $total > 0) {
            $query->limit((int) $total);
        }
        
        if ($category !== null && is_numeric($category) && (int) $category > 0) {
            $query->where('category_id', (int) $category);
        }

        if ($province !== null && is_numeric($province) && (int) $province > 0) {
            $query->where('province_id', (int) $province);
        }

        if ($search !== null) {
            $query->where('name', 'like', '%' . $search . '%');
        }

        $data = $query->orderBy('created_at', 'desc')->get();

        return response()->json([
            'status' => 'success',
            'message' => 'Get all house success',
            'data' => $data
        ]);
    }

    public function getRandomHouse($id){
        try{
            $data = House::with(['user', 'category', 'city', 'province', 'detail', 'singleImage'])->where('category_id', $id)->inRandomOrder()->limit(4)->get();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        }catch(Exception $e){
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

     public function getCategory(){
        try{
            $data = Categories::all();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        }catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function getProvince()
    {
        try {
            $data = Province::get();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function getHouseDetail($id)
    {
        try {
            $data = House::with(['user', 'category', 'city', 'province', 'detail', 'images'])->find($id);
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
}
