<?php

namespace Database\Seeders;

use App\Models\City;
use App\Models\Province;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $provinceIdMap = [
            'Aceh' => 1,
            'Sumatera Utara' => 2,
            'Sumatera Barat' => 3,
            'Riau' => 4,
            'Jambi' => 5,
            'Sumatera Selatan' => 6,
            'Bengkulu' => 7,
            'Lampung' => 8,
            'Kepulauan Bangka Belitung' => 9,
            'Kepulauan Riau' => 10,
            'DKI Jakarta' => 11,
            'Jawa Barat' => 12,
            'Jawa Tengah' => 13,
            'DI Yogyakarta' => 14,
            'Jawa Timur' => 15,
            'Banten' => 16,
            'Bali' => 17,
            'Nusa Tenggara Barat' => 18,
            'Nusa Tenggara Timur' => 19,
            'Kalimantan Barat' => 20,
            'Kalimantan Tengah' => 21,
            'Kalimantan Selatan' => 22,
            'Kalimantan Timur' => 23,
            'Kalimantan Utara' => 24,
            'Sulawesi Utara' => 25,
            'Sulawesi Tengah' => 26,
            'Sulawesi Selatan' => 27,
            'Sulawesi Tenggara' => 28,
            'Gorontalo' => 29,
            'Sulawesi Barat' => 30,
            'Maluku' => 31,
            'Maluku Utara' => 32,
            'Papua' => 33,
            'Papua Barat' => 34,
            'Papua Selatan' => 35,
            'Papua Tengah' => 36,
            'Papua Pegunungan' => 37,
        ];

        $provincesWithCities = [
            'Aceh' => [
                'Banda Aceh', 'Langsa', 'Lhokseumawe', 'Sabang', 'Subulussalam', 'Aceh Barat', 'Aceh Barat Daya',
                'Aceh Besar', 'Aceh Jaya', 'Aceh Selatan', 'Aceh Singkil', 'Aceh Tamiang', 'Aceh Tengah',
                'Aceh Tenggara', 'Aceh Timur', 'Aceh Utara', 'Bener Meriah', 'Bireuen', 'Gayo Lues', 'Nagan Raya',
                'Pidie', 'Pidie Jaya', 'Simeulue',
            ],
            'Sumatera Utara' => [
                'Medan', 'Binjai', 'Tebing Tinggi', 'Pematangsiantar', 'Sibolga', 'Tanjungbalai', 'Padangsidempuan',
                'Dairi', 'Karo', 'Deli Serdang', 'Simalungun', 'Asahan', 'Labuhanbatu', 'Tapanuli Utara',
                'Tapanuli Tengah', 'Tapanuli Selatan', 'Nias', 'Langkat', 'Serdang Bedagai', 'Humbang Hasundutan',
                'Samosir', 'Toba Samosir', 'Pakpak Bharat', 'Padang Lawas', 'Padang Lawas Utara', 'Nias Selatan',
                'Nias Barat', 'Nias Utara', 'Gunungsitoli',
            ],
            'Sumatera Barat' => [
                'Padang', 'Payakumbuh', 'Bukittinggi', 'Solok', 'Sawah Lunto', 'Padang Panjang',
            ],
            'Riau' => [
                'Pekanbaru', 'Dumai', 'Bengkalis', 'Indragiri Hilir', 'Indragiri Hulu', 'Kampar',
                'Kuantan Singingi', 'Pelalawan', 'Rokan Hilir', 'Rokan Hulu', 'Siak',
            ],
            'Jambi' => [
                'Jambi', 'Muaratebo', 'Kuala Tungkal', 'Sarolangun', 'Sungai Penuh',
            ],
            'Sumatera Selatan' => [
                'Palembang', 'Lubuklinggau', 'Prabumulih', 'Pagar Alam', 'Muara Enim', 'Lahat',
            ],
            'Bengkulu' => [
                'Bengkulu',
            ],
            'Lampung' => [
                'Bandar Lampung', 'Metro', 'Lampung Barat', 'Lampung Selatan', 'Lampung Tengah', 'Lampung Timur',
                'Lampung Utara', 'Mesuji', 'Pesawaran', 'Pesisir Barat', 'Pringsewu', 'Tanggamus', 'Tulang Bawang',
                'Tulang Bawang Barat', 'Way Kanan',
            ],
            'Kepulauan Bangka Belitung' => [
                'Pangkal Pinang', 'Koba', 'Sungailiat', 'Toboali', 'Manggar', 'Mentok', 'Bangka', 'Belitung',
                'Bangka Barat', 'Bangka Selatan', 'Bangka Tengah', 'Belitung Timur',
            ],
            'Kepulauan Riau' => [
                'Batam', 'Tanjungpinang', 'Tanjung Balai Karimun', 'Bintan', 'Natuna', 'Lingga', 'Anambas', 'Karimun',
            ],
            'DKI Jakarta' => [
                'Jakarta',
            ],
            'Jawa Barat' => [
                'Bandung', 'Bekasi', 'Bogor', 'Depok', 'Cirebon', 'Sukabumi', 'Tasikmalaya', 'Banjar', 'Cimahi',
                'Cianjur', 'Garut', 'Indramayu', 'Karawang', 'Kuningan', 'Majalengka', 'Pangandaran', 'Purwakarta',
                'Subang', 'Sumedang', 'Ciamis',
            ],
            'Jawa Tengah' => [
                'Semarang', 'Solo', 'Magelang', 'Pekalongan', 'Salatiga', 'Tegal', 'Banjarnegara', 'Banyumas',
                'Batang', 'Blora', 'Boyolali', 'Brebes', 'Cilacap', 'Demak', 'Grobogan', 'Jepara', 'Karanganyar',
                'Kebumen', 'Kendal', 'Klaten', 'Kudus', 'Pati', 'Pemalang', 'Purbalingga', 'Purworejo', 'Rembang',
                'Sragen', 'Sukoharjo', 'Temanggung', 'Wonogiri', 'Wonosobo', 'Purwokerto',
            ],
            'DI Yogyakarta' => [
                'Yogyakarta', 'Bantul', 'Gunungkidul', 'Kulon Progo', 'Sleman',
            ],
            'Jawa Timur' => [
                'Surabaya', 'Malang', 'Kediri', 'Mojokerto', 'Probolinggo', 'Pasuruan', 'Madiun', 'Blitar',
                'Batu', 'Bangkalan', 'Banyuwangi', 'Bojonegoro', 'Bondowoso', 'Gresik', 'Jember', 'Jombang',
                'Lamongan', 'Lumajang', 'Magetan', 'Nganjuk', 'Ngawi', 'Pacitan', 'Pamekasan', 'Ponorogo',
                'Sampang', 'Sidoarjo', 'Situbondo', 'Sumenep', 'Trenggalek', 'Tuban', 'Tulungagung',
            ],
            'Banten' => [
                'Tangerang', 'Serang', 'Cilegon', 'Tangerang Selatan', 'Lebak', 'Pandeglang',
            ],
            'Bali' => [
                'Denpasar', 'Badung', 'Bangli', 'Buleleng', 'Gianyar', 'Jembrana', 'Karangasem', 'Klungkung',
                'Tabanan',
            ],
            'Nusa Tenggara Barat' => [
                'Mataram', 'Bima', 'Dompu', 'Sumbawa', 'Lombok Timur', 'Lombok Tengah', 'Lombok Barat',
                'Lombok Utara', 'Sumbawa Barat',
            ],
            'Nusa Tenggara Timur' => [
                'Kupang', 'Ende', 'Maumere', 'Ruteng', 'Labuan Bajo', 'Waingapu', 'Rote Ndao', 'Sabu Raijua',
                'Timor Tengah Selatan', 'Timor Tengah Utara', 'Belu', 'Alor', 'Lembata', 'Manggarai',
                'Manggarai Barat', 'Nagekeo', 'Sikka', 'Sumba Barat', 'Sumba Barat Daya', 'Sumba Tengah',
                'Sumba Timur',
            ],
            'Kalimantan Barat' => [
                'Pontianak', 'Singkawang', 'Ketapang', 'Sintang', 'Sanggau', 'Putussibau', 'Sambas', 'Melawi',
                'Sekadau', 'Landak', 'Kayong Utara', 'Kubu Raya', 'Mempawah', 'Sukadana',
            ],
            'Kalimantan Tengah' => [
                'Palangkaraya',
            ],
            'Kalimantan Selatan' => [
                'Banjarmasin', 'Banjarbaru',
            ],
            'Kalimantan Timur' => [
                'Samarinda', 'Balikpapan',
            ],
            'Kalimantan Utara' => [
                'Tarakan', 'Nunukan', 'Berau', 'Bulungan', 'Malinau', 'Tana Tidung',
            ],
            'Sulawesi Utara' => [
                'Manado', 'Bitung',
            ],
            'Sulawesi Tengah' => [
                'Palu', 'Donggala', 'Buol', 'Morowali', 'Tojo Una-Una', 'Sigi', 'Parigi Moutong', 'Tolitoli',
                'Poso', 'Banggai', 'Luwuk',
            ],
            'Sulawesi Selatan' => [
                'Makassar', 'Parepare',
            ],
            'Sulawesi Tenggara' => [
                'Kendari', 'Baubau', 'Kolaka', 'Konawe', 'Muna', 'Wakatobi', 'Buton', 'Bombana', 'Kolaka Utara',
                'Konawe Selatan', 'Konawe Utara', 'Buton Utara', 'Muna Barat', 'Konawe Kepulauan',
            ],
            'Gorontalo' => [
                'Gorontalo',
            ],
            'Sulawesi Barat' => [
                
            ],
            'Maluku' => [
                'Ambon',
            ],
            'Maluku Utara' => [
                'Ternate',
            ],
            'Papua' => [
                'Jayapura', 'Mimika', 'Nabire', 'Biak Numfor', 'Merauke', 'Jayawijaya',
            ],
            'Papua Barat' => [
                'Sorong', 'Manokwari', 'Fakfak', 'Kaimana', 'Raja Ampat', 'Teluk Bintuni', 'Teluk Wondama',
                'Maybrat', 'Sorong Selatan', 'Tambrauw', 'Pegunungan Arfak', 'Manokwari Selatan',
            ],
            'Papua Selatan' => [
            ],
            'Papua Tengah' => [
            ],
            'Papua Pegunungan' => [
            ],
        ];

        foreach ($provincesWithCities as $provinceName => $cities) {
            $province = Province::firstOrCreate(['name' => $provinceName]);

            foreach ($cities as $cityName) {
                City::firstOrCreate(
                    ['name' => $cityName, 'province_id' => $province->id],
                    ['name' => $cityName, 'province_id' => $province->id]
                );
            }
        }
    }
}
