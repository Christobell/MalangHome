<?php

namespace App\Http\Controllers\Adminsite;

use App\Http\Controllers\Controller;
use App\Http\Requests\Adminsite\AboutUs\UpdateRules;
use App\Models\AboutUs;
use Illuminate\Http\Request;

class AboutUsController extends Controller
{
    public function getAll(){
        try{    
            $data = AboutUs::all();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data,
            ], 200);
        }catch(\Exception $e){
            return response()->json([
                'status' => false,
                'message' => 'Internal server error',
            ], 500);
        }
    }

    public function update(UpdateRules $request, $id){
        try{
            $data = AboutUs::find($id);
            if(!$data){
                return response()->json([
                    'status' => false,
                    'message' => 'Data not found',
                ], 404);
            }
            $data->update($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data,
            ], 200);
        }catch(\Exception $e){
            return response()->json([
                'status' => false,
                'message' => 'Internal server error',
            ], 500);
        }
    }
}
