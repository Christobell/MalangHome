<?php

namespace App\Http\Requests\Adminsite\AboutUs;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRules extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'string|max:255',
            'description' => 'string|max:255',
            'image' => 'string|max:255',
            'email' => 'string|max:255',
            'phone' => 'string|max:255',
            'address' => 'string|max:255',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'title.string' => 'Title must be a string',
            'title.max' => 'Title must not be greater than 255 characters',
            'description.string' => 'Description must be a string',
            'description.max' => 'Description must not be greater than 255 characters',
            'image.string' => 'Image must be a string',
            'image.max' => 'Image must not be greater than 255 characters',
            'email.string' => 'Email must be a string',
            'email.max' => 'Email must not be greater than 255 characters',
            'phone.string' => 'Phone must be a string',
            'phone.max' => 'Phone must not be greater than 255 characters',
            'address.string' => 'Address must be a string',
            'address.max' => 'Address must not be greater than 255 characters',
        ];
    }
}
