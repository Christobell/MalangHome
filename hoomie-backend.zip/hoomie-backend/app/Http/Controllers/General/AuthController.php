<?php

namespace App\Http\Controllers\General;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRules;
use App\Http\Requests\Auth\RegisterRules;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\PersonalAccessToken;

class AuthController extends Controller
{
    public function register(RegisterRules $request)
    {
        try {
            $request->validated();
            $user = User::create([
                'fullname' => $request->fullname,
                'phone' => $request->phone,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
            $user->assignRole('user');

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $user,
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
                
            ], 500);
        }
    }

    public function login(LoginRules $request)
    {
        try {
            $request->validated();
            $user = User::where('email', $request->email)->first();

            if (!$user) {
                return response()->json([
                    'status' => false,
                    'message' => 'User Not Found',
                ], 404);
            }
            if (!Hash::check($request->password, $user->password)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Wrong Password',
                    'data' => null,
                ], 401);
            }

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => [
                    'id' => $user->id,
                    'fullname' => $user->fullname,
                    'email' => $user->email,
                    'phone' => $user->phone,
                    'roles' => $user->roles->pluck('name')[0],
                    'token' => $user->createToken($user)->plainTextToken,
                    'expires_in' => config('sanctum.expiration'),
                ],
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function logout(Request $request){
        try{
            $token = $request->token;
            $token = PersonalAccessToken::findToken($token);
            if(!$token){
                return response()->json([
                    'status' => false,
                    'message' => 'Token is not valid',
                ], 401);
            }
            $token->delete();
            return response()->json([
                'status' => true,
                'message' => 'Success',
            ], 200);
        }catch(Exception $e){
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }

    public function checkToken(Request $request)
    {
        try {
            if (! $request->has('token')) {
                return response()->json(['status' => false, 'message' => 'Token is missing'], 400);
            }

            $tokenStr = $request->token;

            $token = PersonalAccessToken::findToken($tokenStr);

            if ($token) {
                return response()->json([
                    'status' => true,
                    'message' => 'Success, token is valid.',
                ]);
            }

            return response()->json([
                'status' => false,
                'message' => 'Token is not valid',
            ], 401);

        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
            ], 500);
        }
    }
}
