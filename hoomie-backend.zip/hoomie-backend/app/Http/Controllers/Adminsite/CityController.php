<?php

namespace App\Http\Controllers\Adminsite;

use App\Http\Controllers\Controller;
use App\Http\Requests\Adminsite\City\CreateRules;
use App\Http\Requests\Adminsite\City\UpdateRules;
use App\Models\City;
use Exception;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function getAll(Request $request)
    {
        try {
            $data = City::with('province')->paginate(10, ['*'], 'page', $request->query('page'));
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data->items(),
                'pagination' => [
                    'current_page' => $data->currentPage(),
                    'last_page' => $data->lastPage(),
                    'per_page' => $data->perPage(),
                    'total' => $data->total(),
                ]
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function getOption(){
        try {
            $data = City::all();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }   

    public function getById($id)
    {
        try {
            $data = City::find($id);
            if (!$data) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found'
                ], 404);
            }
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function create(CreateRules $request)
    {
        try {
            $request->validated();
            $city = City::create($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $city
            ], 201);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function update(UpdateRules $request, $id)
    {
        try {
            $request->validated();
            $city = City::find($id);
            if (!$city) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $city->update($request->all());
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $city
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }

    public function delete($id)
    {
        try {
            $city = City::find($id);
            if (!$city) {
                return response()->json([
                    'status' => false,
                    'message' => 'Not Found',
                ], 404);
            }
            $city->delete();
            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => $city
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error'
            ], 500);
        }
    }
}
