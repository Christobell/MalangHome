<?php

use App\Http\Controllers\Adminsite\CategoriesController;
use App\Http\Controllers\Adminsite\CityController;
use App\Http\Controllers\Adminsite\HouseController;
use App\Http\Controllers\Adminsite\OverviewController;
use App\Http\Controllers\Adminsite\ProvinceController;
use App\Http\Controllers\General\AuthController;
use App\Http\Controllers\Guest\HouseController as GuestHouseController;
use Illuminate\Support\Facades\Route;

Route::get('/docs', function () {
    return view('swagger');
});

Route::group([
    'prefix' => 'auth',
], function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/check-token', [AuthController::class, 'checkToken']);
});

Route::group([
    'prefix' => 'adminsite',
    'middleware' => 'checkLogin',
], function () {
    Route::get('/overview', [OverviewController::class, 'getOverview']);
    Route::group([
        'prefix' => 'categories',
    ], function () {
        Route::get('/', [CategoriesController::class, 'getAll']);
        Route::get('/option', [CategoriesController::class, 'getOption']);
        Route::get('/{id}', [CategoriesController::class, 'getById']);
        Route::post('/', [CategoriesController::class, 'create']);
        Route::put('/{id}', [CategoriesController::class, 'update']);
        Route::delete('/{id}', [CategoriesController::class, 'delete']);
    });

    Route::group([
        'prefix' => 'province',
    ], function () {
        Route::get('/', [ProvinceController::class, 'getAll']);
        Route::get('/option', [ProvinceController::class, 'getOption']);
        Route::get('/{id}', [ProvinceController::class, 'getById']);
        Route::post('/', [ProvinceController::class, 'create']);
        Route::put('/{id}', [ProvinceController::class, 'update']);
        Route::delete('/{id}', [ProvinceController::class, 'delete']);
    });

    Route::group([
        'prefix' => 'city',
    ], function () {
        Route::get('/', [CityController::class, 'getAll']);
        Route::get('/option', [CityController::class, 'getOption']);
        Route::get('/{id}', [CityController::class, 'getById']);
        Route::post('/', [CityController::class, 'create']);
        Route::put('/{id}', [CityController::class, 'update']);
        Route::delete('/{id}', [CityController::class, 'delete']);
    });

    Route::group([
        'prefix' => 'house',
    ], function () {
        Route::get('/', [HouseController::class, 'getAll']);
        Route::get('/{id}', [HouseController::class, 'getById']);
        Route::post('/', [HouseController::class, 'create']);
        Route::put('/{id}', [HouseController::class, 'update']);
        Route::delete('/{id}', [HouseController::class, 'delete']);
        Route::get('/image/{id}', [HouseController::class, 'getHouseImage']);
        Route::post('/image/{id}', [HouseController::class, 'addHouseImage']);
        Route::delete('/image/{id}', [HouseController::class, 'deleteHouseImage']);
    });
});

Route::group([
    'prefix' => 'guest',
], function () {
    Route::get('/categories', [GuestHouseController::class, 'getCategory']);
    Route::get('/province', [GuestHouseController::class, 'getProvince']);

    Route::group([
        'prefix' => 'house',
    ], function () {
        Route::get('/', [GuestHouseController::class, 'getHouse']);
        Route::get('/{id}', [GuestHouseController::class, 'getHouseDetail']);
        Route::get('/random/{id}', [GuestHouseController::class, 'getRandomHouse']);
    });
});
