<!DOCTYPE html>
<html>

<head>
    <title>API Documentation</title>
    <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist/swagger-ui.css">
</head>

<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist/swagger-ui-bundle.js"></script>
    <script>
        const ui = SwaggerUIBundle({
            url: "<?php echo e(asset('docs/swagger.json')); ?>?v=<?php echo e(time()); ?>",
            dom_id: '#swagger-ui',
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\USER\OneDrive\Document\TUGAS\PMPL\hoomie-backend\resources\views/swagger.blade.php ENDPATH**/ ?>