<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HouseDetails extends Model
{
    protected $table = 'house_details';

    protected $fillable = [
        'house_id',
        'electrical_power',
        'car_ports',
        'number_of_floors',
        'type',
        'building_orientation',
        'year_built',
        'number_of_bedrooms',
        'description',
        'maps_embed',
    ];

    protected $casts  = [
        'house_id' => 'integer',
        'electrical_power' => 'string',
        'car_ports' => 'string',
        'number_of_floors' => 'string',
        'type' => 'string',
        'building_orientation' => 'string',
        'year_built' => 'string',
        'number_of_bedrooms' => 'string',
        'description' => 'string',
        'maps_embed' => 'string',
        'created_at' => 'datetime:Y-m-d H:i:s',
        'updated_at' => 'datetime:Y-m-d H:i:s',
    ];
}
