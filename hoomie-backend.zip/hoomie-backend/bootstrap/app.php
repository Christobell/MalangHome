<?php

use App\Http\Middleware\checkAuth;
use App\Http\Middleware\checkLogin;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;




return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        // web: __DIR__ . '/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        // commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'checkLogin' => checkLogin::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->render(function (ValidationException $exception, $request) {
            return response()->json([
                'status' => false,
                'message' => 'Validation Error',
                'errors' => $exception->validator->errors(),
            ], 422);
        });

        $exceptions->render(function (AuthenticationException $e, $request) {
            if ($request->expectsJson() || $request->is('api/*') || $request->is('adminsite/*')) {
                return response()->json([
                    'status'  => false,
                    'message' => 'Unauthenticated. Token tidak valid atau expired.',
                ], 401);
            }

            return redirect()->guest(route('login'));
        });

        $exceptions->render(function (Throwable $exception) {
            if ($exception instanceof NotFoundHttpException) {
                return response()->json([
                    'status' => false,
                    'message' => 'Forbidden: route tidak ditemukan.',
                    'data' => null,
                ], 403);
            }

            return response()->json([
                'status' => false,
                'message' => 'Internal Server Error',
                'error' => $exception->getMessage(),
            ], 500);
        });
    })->create();
